const About = () => {
  return (
    <div>
      <h3>Anthony - 66J1234</h3>
    </div>
  );
};

export default About;
