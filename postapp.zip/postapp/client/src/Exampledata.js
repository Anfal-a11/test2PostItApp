export const UsersData = [
  {
    id: 1,
    name: "Dwight Howard",
    email: "dwight@gmail.com",
    password: "12345",
  },

  {
    id: 2,
    name: "Kobe Bryant",
    email: "kobe@gmail.com",
    password: "23456",
  },

  {
    id: 3,
    name: "Lebron James",
    email: "lebron@gmail.com",
    password: "34567",
  },
];
